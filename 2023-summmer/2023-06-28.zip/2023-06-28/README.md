
**Table of Contents**
- [Lecture 07: Statistics with Python](#lecture-07-statistics-with-python)
  - [Topics](#topics)
  - [Course materials](#course-materials)
- [Suggested reading](#suggested-reading)

# Lecture 07: Statistics with Python

## Topics
Here are the topics we are going to cover
* Recap of previous lecture
* Statistics Concepts and Applications
  * Statistical distributions
  * Hypothesis test and confidence interval

## Course materials
* slides [TBD]

# Suggested reading
* [If available] Chapter 6-8 of **Python for Data Analysis: Data Wrangling with pandas, NumPy, and Jupyter** (3rd Edition by Wes McKinney)
* Online resources
  * TBD
 